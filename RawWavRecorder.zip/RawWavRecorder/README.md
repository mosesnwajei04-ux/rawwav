# Raw WAV Recorder

Native Android app. Records uncompressed PCM WAV (16 or 24-bit, mono/stereo,
44.1 to 192 kHz) using the UNPROCESSED audio source, from any input device
including USB-C mics and interfaces. Files go to `Music/RawWavRecorder/`.

Requires Android 10 (API 29) or newer.

## Build the APK with GitHub (no Android Studio)
1. Create a free GitHub account and a new repository.
2. Upload all files from this folder, keeping the folder structure
   (`.github/workflows/build.yml` must stay at that path).
   Easiest from a computer browser: Add file > Upload files, drag in everything.
3. Open the repo's **Actions** tab. The "Build APK" workflow runs automatically
   (or click Run workflow). It takes about 3 to 5 minutes.
4. Open the finished run, download the **RawWavRecorder-apk** artifact, unzip it,
   and install `app-debug.apk` (allow "install unknown apps" when asked).

## Build with Android Studio
Open this folder, let Gradle sync, then Run (or Build > Build APK).

## Notes
- Keep the screen on while recording (the app does this itself).
- The app requests the sample rate you choose. If the USB device runs at a
  different native rate, Android may resample. The status text shows the
  routed input device.
- 24-bit is captured as float and written as packed 24-bit PCM.
