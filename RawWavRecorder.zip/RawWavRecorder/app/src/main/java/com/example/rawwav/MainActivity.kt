package com.example.rawwav

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.MediaRecorder
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private val rates = listOf(44100, 48000, 96000, 192000)
    private var devices: List<AudioDeviceInfo> = emptyList()

    private lateinit var deviceSp: Spinner
    private lateinit var rateSp: Spinner
    private lateinit var bitSp: Spinner
    private lateinit var chSp: Spinner
    private lateinit var timeTv: TextView
    private lateinit var statusTv: TextView
    private lateinit var meter: ProgressBar
    private lateinit var recBtn: Button
    private lateinit var audioManager: AudioManager

    @Volatile private var recording = false
    private var worker: Thread? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        audioManager = getSystemService(AudioManager::class.java)
        buildUi()
        refreshDevices()
        audioManager.registerAudioDeviceCallback(object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) = refreshDevices()
            override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) = refreshDevices()
        }, null)
    }

    override fun onDestroy() {
        recording = false
        super.onDestroy()
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(36), dp(20), dp(24))
        }
        fun label(t: String) = root.addView(TextView(this).apply {
            text = t; textSize = 12f; alpha = 0.7f; setPadding(0, dp(14), 0, dp(2))
        })
        fun spinner(items: List<String>, sel: Int = 0) = Spinner(this).also {
            it.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items).apply {
                setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            }
            it.setSelection(sel)
            root.addView(it)
        }

        root.addView(TextView(this).apply { text = "Raw WAV Recorder"; textSize = 24f })
        root.addView(TextView(this).apply {
            text = "Unprocessed PCM straight to WAV"; alpha = 0.7f
        })

        label("INPUT DEVICE")
        deviceSp = spinner(listOf("System default"))
        label("SAMPLE RATE")
        rateSp = spinner(rates.map { "${it / 1000.0} kHz" }, 1)
        label("BIT DEPTH")
        bitSp = spinner(listOf("16-bit", "24-bit"), 1)
        label("CHANNELS")
        chSp = spinner(listOf("Mono", "Stereo"))

        meter = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(14)).apply {
                topMargin = dp(24)
            }
        }
        root.addView(meter)

        timeTv = TextView(this).apply {
            text = "00:00"; textSize = 48f; gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(timeTv)

        recBtn = Button(this).apply {
            text = "Record"; textSize = 18f
            setOnClickListener { if (recording) recording = false else startRecording() }
        }
        root.addView(recBtn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(64)))

        statusTv = TextView(this).apply {
            text = "Ready."; alpha = 0.8f; setPadding(0, dp(16), 0, 0)
        }
        root.addView(statusTv)

        setContentView(ScrollView(this).apply { addView(root) })
    }

    private fun setControlsEnabled(on: Boolean) {
        listOf(deviceSp, rateSp, bitSp, chSp).forEach { it.isEnabled = on }
    }

    private fun typeName(t: Int) = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_MIC -> "Built-in mic"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB"
        AudioDeviceInfo.TYPE_USB_HEADSET -> "USB headset"
        AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Wired headset"
        AudioDeviceInfo.TYPE_BLUETOOTH_SCO -> "Bluetooth"
        else -> "Input"
    }

    private fun refreshDevices() {
        if (recording) return
        val selectedId = devices.getOrNull(deviceSp.selectedItemPosition - 1)?.id
        devices = audioManager.getDevices(AudioManager.GET_DEVICES_INPUTS).toList()
        val names = listOf("System default") +
            devices.map { "${typeName(it.type)}: ${it.productName}" }
        deviceSp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, names).apply {
            setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        }
        val idx = devices.indexOfFirst { it.id == selectedId }
        // Auto-select a USB device when one is plugged in
        val usb = devices.indexOfFirst {
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE || it.type == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        deviceSp.setSelection(if (idx >= 0) idx + 1 else if (usb >= 0) usb + 1 else 0)
    }

    private fun status(s: String) = runOnUiThread { statusTv.text = s }

    // ---------- Recording ----------

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(code, perms, res)
        if (res.firstOrNull() == PackageManager.PERMISSION_GRANTED) startRecording()
        else status("Microphone permission is required.")
    }

    private fun startRecording() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            return
        }
        val rate = rates[rateSp.selectedItemPosition]
        val bits = if (bitSp.selectedItemPosition == 0) 16 else 24
        val ch = if (chSp.selectedItemPosition == 0) 1 else 2
        val mask = if (ch == 1) AudioFormat.CHANNEL_IN_MONO else AudioFormat.CHANNEL_IN_STEREO
        // 24-bit is captured as float and converted to packed 24-bit PCM
        val enc = if (bits == 16) AudioFormat.ENCODING_PCM_16BIT else AudioFormat.ENCODING_PCM_FLOAT

        val minBuf = AudioRecord.getMinBufferSize(rate, mask, enc)
        if (minBuf <= 0) {
            status("This format isn't supported: ${rate / 1000.0} kHz, $ch ch, $bits-bit.")
            return
        }
        val unprocessedOk =
            audioManager.getProperty(AudioManager.PROPERTY_SUPPORT_AUDIO_SOURCE_UNPROCESSED) == "true"
        val source = if (unprocessedOk) MediaRecorder.AudioSource.UNPROCESSED
        else MediaRecorder.AudioSource.MIC

        val rec = try {
            AudioRecord.Builder()
                .setAudioSource(source)
                .setAudioFormat(
                    AudioFormat.Builder().setEncoding(enc).setSampleRate(rate).setChannelMask(mask).build()
                )
                .setBufferSizeInBytes(minBuf * 4)
                .build()
        } catch (e: Exception) {
            status("Couldn't open input: ${e.message}")
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            status("Input failed to initialize at ${rate / 1000.0} kHz. Try a lower rate.")
            return
        }
        devices.getOrNull(deviceSp.selectedItemPosition - 1)?.let { rec.setPreferredDevice(it) }

        val name = "rec_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav"
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, name)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/wav")
            put(MediaStore.Audio.Media.RELATIVE_PATH, Environment.DIRECTORY_MUSIC + "/RawWavRecorder")
            put(MediaStore.Audio.Media.IS_PENDING, 1)
        }
        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
        if (uri == null) {
            rec.release()
            status("Couldn't create the output file.")
            return
        }

        recording = true
        recBtn.text = "Stop"
        setControlsEnabled(false)
        worker = Thread { recordLoop(rec, uri, name, rate, bits, ch) }.also { it.start() }
    }

    private fun recordLoop(rec: AudioRecord, uri: Uri, name: String, rate: Int, bits: Int, ch: Int) {
        var total = 0L
        val bytesPerFrame = ch * bits / 8
        try {
            contentResolver.openFileDescriptor(uri, "rw")!!.use { pfd ->
                val channel = FileOutputStream(pfd.fileDescriptor).channel
                fun write(b: ByteBuffer) { while (b.hasRemaining()) channel.write(b) }
                write(wavHeader(0, rate, ch, bits))

                rec.startRecording()
                val routed = rec.routedDevice?.let { "${typeName(it.type)}: ${it.productName}" } ?: "unknown"
                val srcName = if (rec.audioSource == MediaRecorder.AudioSource.UNPROCESSED)
                    "UNPROCESSED" else "MIC (unprocessed source unsupported)"
                status("Recording $name\n${rate / 1000.0} kHz, $bits-bit, $ch ch\nSource: $srcName\nInput: $routed")

                val frames = 2048
                val shorts = ShortArray(frames * ch)
                val floats = FloatArray(frames * ch)
                var lastUi = 0L

                while (recording) {
                    var peak = 0f
                    val out: ByteBuffer
                    if (bits == 16) {
                        val n = rec.read(shorts, 0, shorts.size)
                        if (n <= 0) break
                        out = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
                        out.asShortBuffer().put(shorts, 0, n)
                        for (i in 0 until n) peak = maxOf(peak, abs(shorts[i].toInt()) / 32768f)
                    } else {
                        val n = rec.read(floats, 0, floats.size, AudioRecord.READ_BLOCKING)
                        if (n <= 0) break
                        out = ByteBuffer.allocate(n * 3)
                        for (i in 0 until n) {
                            val s = floats[i].coerceIn(-1f, 1f)
                            peak = maxOf(peak, abs(s))
                            val v = (s * 8388607f).roundToInt()
                            out.put(v.toByte()).put((v shr 8).toByte()).put((v shr 16).toByte())
                        }
                    }
                    out.flip()
                    total += out.remaining()
                    write(out)

                    val now = System.currentTimeMillis()
                    if (now - lastUi > 100) {
                        lastUi = now
                        val secs = total / bytesPerFrame / rate
                        val level = (peak * 100).toInt()
                        runOnUiThread {
                            meter.progress = level
                            timeTv.text = "%02d:%02d".format(secs / 60, secs % 60)
                        }
                    }
                }
                rec.stop()

                // Rewrite the header with the real length
                channel.position(0)
                write(wavHeader(total, rate, ch, bits))
                channel.force(true)
            }
            contentResolver.update(uri, ContentValues().apply {
                put(MediaStore.Audio.Media.IS_PENDING, 0)
            }, null, null)
            status("Saved: Music/RawWavRecorder/$name\n${"%.1f".format(total / 1048576.0)} MB")
        } catch (e: Exception) {
            contentResolver.delete(uri, null, null)
            status("Recording failed: ${e.message}")
        } finally {
            rec.release()
            recording = false
            runOnUiThread {
                recBtn.text = "Record"
                meter.progress = 0
                setControlsEnabled(true)
                refreshDevices()
            }
        }
    }

    private fun wavHeader(dataLen: Long, rate: Int, ch: Int, bits: Int): ByteBuffer {
        val b = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
        b.put("RIFF".toByteArray()).putInt((36 + dataLen).toInt())
        b.put("WAVE".toByteArray()).put("fmt ".toByteArray())
        b.putInt(16).putShort(1).putShort(ch.toShort())
        b.putInt(rate).putInt(rate * ch * bits / 8)
        b.putShort((ch * bits / 8).toShort()).putShort(bits.toShort())
        b.put("data".toByteArray()).putInt(dataLen.toInt())
        b.flip()
        return b
    }
}
